#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 1000


int load_data(const char *filename, double data[], int max_size) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return -1;
    }
    
    int count = 0;
    while (fscanf(file, "%lf", &data[count]) != EOF && count < max_size) {
        count++;
    }
    fclose(file);
    return count;
}


void find_peaks_and_minima(double data[], int size, int indices[], double values[], int *max_count, int *min_count) {
    *max_count = 0;
    *min_count = 0;
    
    for (int i = 1; i < size - 1; i++) {
        if (data[i] > data[i - 1] && data[i] > data[i + 1]) {
            indices[(*max_count)] = i;
            values[(*max_count)] = data[i];
            (*max_count)++;
        } else if (data[i] < data[i - 1] && data[i] < data[i + 1]) {
            indices[(*min_count)] = i;
            values[(*min_count)] = data[i];
            (*min_count)++;
        }
    }
}

void print_results(int indices[], double values[], int count, const char *type) {
    printf("%s:\n", type);
    for (int i = 0; i < count; i++) {
        printf("Index: %d, Value: %.2f\n", indices[i], values[i]);
    }
}

int main() {
    double data[MAX_SIZE];
    int indices[MAX_SIZE];
    double values[MAX_SIZE];
    int count, max_count, min_count;

    count = load_data("Data_1.txt", data, MAX_SIZE);
    if (count < 0) return 1;

    find_peaks_and_minima(data, count, indices, values, &max_count, &min_count);
    printf("Data 1 Maxima:\n");
    print_results(indices, values, max_count, "Maxima");
    printf("Data 1 Minima:\n");
    print_results(indices, values, min_count, "Minima");

    // Load and process Data 2
    count = load_data("Data_2.txt", data, MAX_SIZE);
    if (count < 0) return 1;

    find_peaks_and_minima(data, count, indices, values, &max_count, &min_count);
    printf("Data 2 Maxima:\n");
    print_results(indices, values, max_count, "Maxima");
    printf("Data 2 Minima:\n");
    print_results(indices, values, min_count, "Minima");

    return 0;
}
